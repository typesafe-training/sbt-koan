package name.heikoseeberger.koan

import org.scalatest._

class AddSpec extends WordSpec with Matchers {

  "Calling add" should {
    "return the sum of the two arguments" in {
      Add.add(1, 2) shouldEqual 3
    }
  }
}
