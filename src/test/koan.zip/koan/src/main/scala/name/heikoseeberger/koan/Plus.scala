package name.heikoseeberger.koan

object Add {

  def add(x: Int, y: Int): Int =
    x + y
}
